var searchData=
[
  ['quality_20of_20service_704',['Quality of service',['../qos.html',1,'']]]
];
